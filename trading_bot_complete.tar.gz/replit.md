# Trading Signal Bot

## Overview

This is a Telegram trading signal bot that provides automated trading signals for forex pairs (XAUUSD, EURUSD, GBPUSD) using technical analysis. The bot combines RSI (Relative Strength Index) and Fibonacci retracement analysis to generate trading signals with confidence levels, stop losses, and take profit targets.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

**2025-07-17**: Successfully fixed critical async event loop issue and restored full functionality
- ✅ Fixed "Cannot close a running event loop" error in main.py
- ✅ Updated Telegram bot initialization to use proper async handling
- ✅ Improved error handling and graceful shutdown procedures
- ✅ Restored market scanner functionality with proper rate limiting
- ✅ Bot now starts successfully and processes signals continuously
- ✅ Multi-timeframe analysis working (1H, 4H, Daily)
- ✅ Fallback data system active for demonstration purposes

**Status**: Bot is now running successfully and processing market data

## System Architecture

The application follows a modular, event-driven architecture with clear separation of concerns:

### Core Components
- **Main Application**: Entry point that coordinates all components
- **Telegram Bot**: Handles user interactions and command processing
- **Signal Generation**: Core trading logic combining RSI and Fibonacci analysis
- **Data Provider**: Fetches market data from Alpha Vantage API
- **Market Scanner**: Continuous monitoring and signal generation
- **Storage**: File-based storage for signals and performance tracking

### Architecture Pattern
The system uses a layered architecture with:
1. **Presentation Layer**: Telegram bot interface
2. **Business Logic Layer**: Signal generation and analysis
3. **Data Access Layer**: Market data provider and storage
4. **External Services**: Alpha Vantage API for market data

## Key Components

### 1. Telegram Bot (`bot/`)
- **TradingSignalBot**: Main bot class handling Telegram integration
- **BotCommands**: Command handlers for user interactions
- Supports commands: /start, /help, /status, /signals, /subscribe, /analyze

### 2. Signal Generation (`signals/`)
- **SignalGenerator**: Main signal generation logic
- **RiskManagement**: Position sizing and risk calculations
- Combines RSI and Fibonacci analysis for signal confirmation

### 3. Technical Analysis (`analysis/`)
- **RSIAnalyzer**: RSI calculation and signal generation
- **FibonacciAnalysis**: Fibonacci retracement level calculations
- **TechnicalAnalysis**: Base technical indicators (RSI, SMA, EMA)

### 4. Data Management (`data/`, `storage/`)
- **DataProvider**: Alpha Vantage API integration with rate limiting
- **SignalStorage**: File-based storage for signals and performance metrics
- Uses CSV for signal history and JSON for performance tracking

### 5. Market Monitoring (`scheduler/`)
- **MarketScanner**: Continuous market monitoring
- Implements rate limiting and signal cooldown periods
- Configurable scan intervals and daily signal limits

## Data Flow

1. **Market Data Collection**: DataProvider fetches price data from Alpha Vantage API
2. **Technical Analysis**: RSI and Fibonacci levels are calculated from price data
3. **Signal Generation**: SignalGenerator combines analysis results to create trading signals
4. **Risk Management**: Position sizing and stop loss/take profit levels are calculated
5. **Signal Storage**: Generated signals are stored in CSV format
6. **Telegram Delivery**: Signals are sent to subscribed users via Telegram bot
7. **Performance Tracking**: Signal outcomes are tracked for performance analysis

## External Dependencies

### APIs
- **Alpha Vantage API**: Primary data source for forex and gold prices
- **Telegram Bot API**: For bot communication and user interaction

### Python Libraries
- **python-telegram-bot**: Telegram bot framework
- **pandas**: Data manipulation and analysis
- **numpy**: Numerical computations
- **requests**: HTTP client for API calls
- **python-dotenv**: Environment variable management

### Configuration
- Environment variables for API keys (TELEGRAM_BOT_TOKEN, ALPHA_VANTAGE_API_KEY)
- JSON configuration file for trading parameters and bot settings

## Deployment Strategy

### Environment Setup
- Uses environment variables for sensitive configuration (API keys)
- Supports development and production environments
- Configurable logging levels and file rotation

### File Storage
- Local file system for signal history and performance data
- CSV format for signal data (easy to analyze and export)
- JSON format for performance metrics and configuration

### Rate Limiting
- Implements API rate limiting for Alpha Vantage (5 requests per minute)
- Signal cooldown periods to prevent spam
- Configurable request intervals and retry mechanisms

### Error Handling
- Comprehensive logging system with file rotation
- Graceful error handling with fallback mechanisms
- Telegram error handler for bot-related issues

### Scalability Considerations
- Modular design allows easy addition of new trading pairs
- Configurable timeframes and analysis parameters
- Extensible signal generation system for new technical indicators

Note: The application currently uses file-based storage but is architected to easily migrate to a database system like PostgreSQL for improved scalability and concurrent access.